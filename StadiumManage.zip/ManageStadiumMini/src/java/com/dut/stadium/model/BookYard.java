/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dut.stadium.model;

import java.util.Date;
import java.util.UUID;

/**
 *
 * @author VuDang
 */
public class BookYard {
    
	private int IDBook;
	private Date DateBook;
	private String IDCustomer;
	private boolean Status;
	private String Contents;
	private String IDYard ;
	private int IDTimeSlot;
        private String ListIDService;
	
}
