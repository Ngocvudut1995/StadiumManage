/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dut.stadium.model;

/**
 *
 * @author VuDang
 */
public class TimeSlot {
    
    private int	IDTimeSlot;
private String	TimeSlot;

    public int getIDTimeSlot() {
        return IDTimeSlot;
    }

    public void setIDTimeSlot(int IDTimeSlot) {
        this.IDTimeSlot = IDTimeSlot;
    }

    public String getTimeSlot() {
        return TimeSlot;
    }

    public void setTimeSlot(String TimeSlot) {
        this.TimeSlot = TimeSlot;
    }
}
